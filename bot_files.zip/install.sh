#!/bin/bash
set -e

echo ""
echo "🎵 Music Bot by TRE — Установка"
echo "================================"
echo ""

# ── Node.js ──────────────────────────────────────────────────────────────────
if ! command -v node &> /dev/null; then
  echo "📦 Устанавливаю Node.js 20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash - > /dev/null 2>&1
  sudo apt-get install -y nodejs > /dev/null 2>&1
  echo "✅ Node.js установлен"
else
  echo "✅ Node.js уже есть: $(node -v)"
fi

# ── pnpm ─────────────────────────────────────────────────────────────────────
if ! command -v pnpm &> /dev/null; then
  echo "📦 Устанавливаю pnpm..."
  npm install -g pnpm > /dev/null 2>&1
  echo "✅ pnpm установлен"
else
  echo "✅ pnpm уже есть"
fi

# ── ffmpeg ────────────────────────────────────────────────────────────────────
if ! command -v ffmpeg &> /dev/null; then
  echo "📦 Устанавливаю ffmpeg..."
  sudo apt-get install -y ffmpeg > /dev/null 2>&1
  echo "✅ ffmpeg установлен"
else
  echo "✅ ffmpeg уже есть"
fi

# ── yt-dlp ───────────────────────────────────────────────────────────────────
if ! command -v yt-dlp &> /dev/null; then
  echo "📦 Устанавливаю yt-dlp..."
  sudo curl -sL https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp
  sudo chmod a+rx /usr/local/bin/yt-dlp
  echo "✅ yt-dlp установлен"
else
  echo "✅ yt-dlp уже есть"
fi

# ── .env ─────────────────────────────────────────────────────────────────────
if [ ! -f .env ]; then
  echo ""
  echo "🔑 Введи токен бота (получить у @BotFather в Telegram):"
  read -r TOKEN
  echo ""
  echo "👑 Введи свой Telegram ID (узнать у /myid в боте или @userinfobot):"
  read -r ADMIN_ID
  cat > .env <<EOF
TELEGRAM_BOT_TOKEN=$TOKEN
ADMIN_IDS=$ADMIN_ID
PORT=8080
NODE_ENV=production
EOF
  echo "✅ Файл .env создан"
else
  echo "✅ Файл .env уже есть"
fi

# ── Зависимости ───────────────────────────────────────────────────────────────
echo ""
echo "📦 Устанавливаю зависимости..."
pnpm install > /dev/null 2>&1
echo "✅ Зависимости установлены"

# ── Сборка ────────────────────────────────────────────────────────────────────
echo "🔨 Собираю бот..."
node ./build.mjs
echo "✅ Собрано"

# ── PM2 ──────────────────────────────────────────────────────────────────────
if ! command -v pm2 &> /dev/null; then
  echo "📦 Устанавливаю PM2 (автозапуск)..."
  npm install -g pm2 > /dev/null 2>&1
fi

pm2 delete musicbot 2>/dev/null || true
pm2 start "node --env-file=.env --enable-source-maps ./dist/index.mjs" --name musicbot
pm2 save > /dev/null 2>&1
pm2 startup 2>/dev/null || true

echo ""
echo "╔══════════════════════════════════════╗"
echo "║  ✅ Бот запущен и работает 24/7!     ║"
echo "╚══════════════════════════════════════╝"
echo ""
echo "  pm2 logs musicbot      — логи"
echo "  pm2 restart musicbot   — перезапустить"
echo "  pm2 stop musicbot      — остановить"
echo ""
