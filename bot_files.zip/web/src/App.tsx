import { Music, Headphones, Zap, Waves, Radio, ChevronRight } from "lucide-react";

const BOT_USERNAME = "Mtremusicbot";

const effects = [
  { icon: "🌊", name: "Slowed + Reverb" },
  { icon: "⚡", name: "Nightcore" },
  { icon: "🔊", name: "Bass Boost" },
  { icon: "💥", name: "Ultra Bass" },
  { icon: "🎧", name: "8D Audio" },
  { icon: "🔥", name: "Phonk Bass" },
  { icon: "🤘", name: "Hard Bass" },
  { icon: "🌐", name: "3D Audio" },
  { icon: "🎶", name: "Reverb" },
  { icon: "📢", name: "Echo" },
  { icon: "🎬", name: "Dolby Atmos" },
  { icon: "🌍", name: "Spatial Audio" },
];

const steps = [
  { num: "01", title: "Пиши название", desc: "Напиши имя артиста или название песни — на любом языке" },
  { num: "02", title: "Выбери из 5", desc: "Бот найдёт 5 похожих треков — выбери нужный" },
  { num: "03", title: "Слушай", desc: "Получи mp3 прямо в Telegram и выбери любой эффект" },
];

export default function App() {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white overflow-x-hidden">

      {/* Hero */}
      <div className="relative flex flex-col items-center justify-center min-h-screen px-6 text-center">
        {/* glow */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-purple-600/20 blur-[120px]" />
          <div className="absolute top-2/3 left-1/4 w-[300px] h-[300px] rounded-full bg-blue-600/15 blur-[100px]" />
          <div className="absolute top-1/4 right-1/4 w-[250px] h-[250px] rounded-full bg-pink-600/10 blur-[100px]" />
        </div>

        <div className="relative z-10 max-w-3xl mx-auto">
          {/* badge */}
          <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 text-sm text-purple-300 mb-8">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            Бот работает 24/7
          </div>

          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
              <Music size={40} />
            </div>
          </div>

          <h1 className="text-5xl sm:text-6xl font-bold mb-4 bg-gradient-to-r from-white via-purple-200 to-blue-300 bg-clip-text text-transparent leading-tight">
            Music Bot
          </h1>
          <p className="text-lg sm:text-xl text-white/50 mb-10 max-w-xl mx-auto">
            Ищи и скачивай музыку прямо в Telegram.<br />
            Выбирай из 5 вариантов и применяй эффекты.
          </p>

          <a
            href={`https://t.me/${BOT_USERNAME}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-400 hover:to-blue-500 transition-all px-8 py-4 rounded-2xl text-lg font-semibold shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 hover:scale-105"
          >
            Открыть в Telegram
            <ChevronRight size={20} />
          </a>
        </div>

        {/* scroll hint */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/30 text-sm animate-bounce">
          <span>↓</span>
        </div>
      </div>

      {/* How it works */}
      <section className="px-6 py-24 max-w-5xl mx-auto">
        <h2 className="text-3xl sm:text-4xl font-bold text-center mb-4">Как это работает</h2>
        <p className="text-white/40 text-center mb-14">Три простых шага</p>
        <div className="grid sm:grid-cols-3 gap-6">
          {steps.map((s) => (
            <div key={s.num} className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:border-purple-500/30 transition-colors">
              <div className="text-4xl font-bold text-purple-500/40 mb-4">{s.num}</div>
              <h3 className="text-lg font-semibold mb-2">{s.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Effects */}
      <section className="px-6 py-24 bg-white/[0.02]">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-center mb-4">Эффекты</h2>
          <p className="text-white/40 text-center mb-14">21 эффект — включая комбо</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {effects.map((e) => (
              <div key={e.name} className="bg-white/5 border border-white/8 rounded-xl px-4 py-3 flex items-center gap-3 hover:border-purple-500/30 hover:bg-white/8 transition-all">
                <span className="text-xl">{e.icon}</span>
                <span className="text-sm font-medium text-white/80">{e.name}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-6 py-24 max-w-5xl mx-auto">
        <div className="grid sm:grid-cols-3 gap-6">
          {[
            { icon: <Radio size={24} />, title: "Поиск по YouTube", desc: "Находит музыку по названию или артисту, русские и зарубежные треки" },
            { icon: <Headphones size={24} />, title: "5 вариантов", desc: "Выбирай из 5 найденных треков — не будет путаницы с ремиксами" },
            { icon: <Zap size={24} />, title: "Быстро и бесплатно", desc: "Скачивание за секунды, без регистрации и лимитов" },
            { icon: <Waves size={24} />, title: "Аудио эффекты", desc: "8D, Slowed, Bass Boost, Nightcore и ещё 17 эффектов" },
            { icon: <Music size={24} />, title: "MP3 качество", desc: "Высокое качество звука, скачивается прямо в чат" },
            { icon: <span className="text-2xl">🌍</span>, title: "Любой язык", desc: "Русская, английская, корейская и любая другая музыка" },
          ].map((f, i) => (
            <div key={i} className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:border-purple-500/30 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-400 mb-4">{f.icon}</div>
              <h3 className="font-semibold mb-2">{f.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 py-24 text-center">
        <div className="max-w-xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Попробуй сейчас</h2>
          <p className="text-white/40 mb-10">Бесплатно, без регистрации</p>
          <a
            href={`https://t.me/${BOT_USERNAME}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-400 hover:to-blue-500 transition-all px-8 py-4 rounded-2xl text-lg font-semibold shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 hover:scale-105"
          >
            Открыть в Telegram
            <ChevronRight size={20} />
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 px-6 py-8 text-center text-white/25 text-sm">
        @Mtremusicbot · by TRE · Работает 24/7
      </footer>
    </div>
  );
}
