#!/bin/bash

echo "🎵 Music Bot by TRE — Запуск"
echo ""

if [ ! -f .env ]; then
  echo "❌ Файл .env не найден!"
  echo "   Сначала запусти: ./install.sh"
  exit 1
fi

if [ ! -f dist/index.mjs ]; then
  echo "🔨 Первый запуск — собираю проект..."
  pnpm install > /dev/null 2>&1
  node ./build.mjs
fi

echo "🚀 Бот запущен. Нажми Ctrl+C чтобы остановить."
echo ""
node --env-file=.env --enable-source-maps ./dist/index.mjs
