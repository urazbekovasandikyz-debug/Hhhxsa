import { Telegraf, Markup } from "telegraf";
import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs";
import path from "path";
import os from "os";

const execAsync = promisify(exec);

const BOT_TOKEN = process.env["TELEGRAM_BOT_TOKEN"];
if (!BOT_TOKEN) throw new Error("TELEGRAM_BOT_TOKEN is required");

export const bot = new Telegraf(BOT_TOKEN);

// Используем системные бинарники (установленные через apt/pip)
const YT_DLP_PATH = process.env["YT_DLP_PATH"] ?? "yt-dlp";
const FFMPEG_PATH = process.env["FFMPEG_PATH"] ?? "ffmpeg";

// ─── Config ───────────────────────────────────────────────────────────────────

const CONFIG_PATH = path.join(process.cwd(), "data", "botconfig.json");

interface BotConfig {
  admin_ids: number[];
  start_message: string;
  help_message: string;
  about_message: string;
}

const DEFAULT_CONFIG: BotConfig = {
  admin_ids: [],
  start_message:
    "🎵 *Привет! Я музыкальный бот*\n\n" +
    "Напиши название песни или артиста — я найду *5 вариантов*, ты выберешь нужный и я скачаю.\n\n" +
    "После скачивания выбери любой *ремикс-эффект* 🎧\n\n" +
    "Все ремиксы — настоящие версии с YouTube!",
  help_message:
    "🎵 *Как пользоваться ботом:*\n\n" +
    "1️⃣ Напиши название песни или артиста\n" +
    "2️⃣ Выбери из 5 найденных вариантов\n" +
    "3️⃣ Подожди пока скачаю\n" +
    "4️⃣ Выбери эффект — бот найдёт готовый ремикс на YouTube!\n\n" +
    "*Доступные эффекты:*\n" +
    "🌊 Slowed+Reverb · ⚡ Nightcore · 🔊 Bass Boost\n" +
    "💥 Ultra Bass · 🎧 8D Audio · 🔥 Phonk\n" +
    "🤘 Hard Bass · 🎶 Reverb · 📢 Echo · ☁️ Lo-Fi\n\n" +
    "/about — о боте",
  about_message:
    "🤖 *О боте*\n\n" +
    "Этот бот ищет музыку на YouTube, скачивает её и находит готовые ремиксы — никакой компьютерной обработки!\n\n" +
    "Все версии (Slowed, Nightcore и т.д.) — реальные треки с YouTube 🎧",
};

function loadConfig(): BotConfig {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const raw = fs.readFileSync(CONFIG_PATH, "utf8");
      return { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
    }
  } catch {}
  return { ...DEFAULT_CONFIG };
}

function saveConfig(cfg: BotConfig): void {
  const dir = path.dirname(CONFIG_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2), "utf8");
}

let config = loadConfig();

function isAdmin(userId: number): boolean {
  const envIds = (process.env["ADMIN_IDS"] ?? "")
    .split(",")
    .map((s) => parseInt(s.trim()))
    .filter((n) => !isNaN(n));
  return config.admin_ids.includes(userId) || envIds.includes(userId);
}

// ─── Effects ──────────────────────────────────────────────────────────────────

const EFFECTS: Record<string, { label: string; searchTerm: string }> = {
  slowed_reverb:  { label: "🌊 Slowed + Reverb",    searchTerm: "slowed reverb" },
  nightcore:      { label: "⚡ Nightcore",            searchTerm: "nightcore" },
  bass_boost:     { label: "🔊 Bass Boost",           searchTerm: "bass boosted" },
  ultra_bass:     { label: "💥 Ultra Bass",           searchTerm: "ultra bass boost" },
  audio_8d:       { label: "🎧 8D Audio",             searchTerm: "8D audio" },
  phonk:          { label: "🔥 Phonk",               searchTerm: "phonk remix" },
  hard_bass:      { label: "🤘 Hard Bass",            searchTerm: "hard bass" },
  reverb:         { label: "🎶 Reverb",              searchTerm: "reverb" },
  echo:           { label: "📢 Echo",                searchTerm: "echo remix" },
  lofi:           { label: "☁️ Lo-Fi",               searchTerm: "lofi remix" },
  nightcore_bass: { label: "⚡🔊 Nightcore + Bass",  searchTerm: "nightcore bass boosted" },
  "8d_reverb":    { label: "🎧🎶 8D + Reverb",       searchTerm: "8D reverb" },
  slowed_bass:    { label: "🌊🔊 Slowed + Bass",     searchTerm: "slowed bass boosted" },
  phonk_reverb:   { label: "🔥🎶 Phonk + Reverb",   searchTerm: "phonk reverb" },
};

// ─── Types ────────────────────────────────────────────────────────────────────

type SearchResult = { title: string; videoId: string; uploader: string };
type AdminAction = "start" | "help" | "about" | "add_admin";

const searchResultsCache = new Map<number, SearchResult[]>();
const pendingRemix = new Map<
  number,
  { title: string; videoId: string; uploader: string; originalFile: string }
>();
const pendingAdminAction = new Map<number, AdminAction>();

// ─── YouTube helpers ──────────────────────────────────────────────────────────

function parseArtist(title: string, uploader: string): string {
  // "Artist - Song Title" format
  const dash = title.indexOf(" - ");
  if (dash > 0) return title.slice(0, dash).trim();
  // Remove VEVO / Topic suffixes from channel name
  return uploader.replace(/\s*-\s*Topic$/i, "").replace(/VEVO$/i, "").trim() || uploader;
}

async function searchYouTube(query: string): Promise<SearchResult[]> {
  const { stdout } = await execAsync(
    `"${YT_DLP_PATH}" "ytsearch5:${query}" --print "%(title)s|||%(id)s|||%(channel)s" --no-playlist --playlist-items 1-5 --no-warnings`,
    { timeout: 45000 }
  );
  const results: SearchResult[] = [];
  for (const line of stdout.trim().split("\n")) {
    const parts = line.split("|||");
    if (parts.length < 2) continue;
    const title    = parts[0]?.trim() ?? "";
    const videoId  = parts[1]?.trim() ?? "";
    const uploader = parts[2]?.trim() ?? "";
    if (title && videoId) results.push({ title, videoId, uploader });
    if (results.length >= 5) break;
  }
  return results;
}

async function downloadAudio(videoId: string, outputPath: string): Promise<void> {
  const ytUrl = `https://www.youtube.com/watch?v=${videoId}`;
  const cmd = [
    `"${YT_DLP_PATH}"`,
    `-x --audio-format mp3 --audio-quality 0`,
    `--ffmpeg-location "${FFMPEG_PATH}"`,
    `--no-embed-metadata --no-embed-thumbnail`,
    `-o "${outputPath}"`,
    `"${ytUrl}" --no-playlist`,
  ].join(" ");
  await execAsync(cmd, { timeout: 180000 });
}

async function findAndDownloadRemix(
  songTitle: string,
  effectSearchTerm: string,
  outputPath: string
): Promise<{ remixTitle: string; remixArtist: string }> {
  const query = `${songTitle} ${effectSearchTerm}`;
  const { stdout } = await execAsync(
    `"${YT_DLP_PATH}" "ytsearch1:${query}" --print "%(title)s|||%(id)s|||%(channel)s" --no-playlist --playlist-items 1 --no-warnings`,
    { timeout: 45000 }
  );
  const line  = stdout.trim().split("\n")[0] ?? "";
  const parts = line.split("|||");
  const remixTitle    = parts[0]?.trim() ?? songTitle;
  const remixVideoId  = parts[1]?.trim() ?? "";
  const remixUploader = parts[2]?.trim() ?? "";

  if (!remixVideoId) throw new Error("No remix found on YouTube");

  await downloadAudio(remixVideoId, outputPath);
  return {
    remixTitle,
    remixArtist: parseArtist(remixTitle, remixUploader),
  };
}

// ─── Markdown helpers ─────────────────────────────────────────────────────────

function md(text: string): string {
  return text.replace(/[_*`\[]/g, "\\$&");
}

function shortTitle(title: string, max = 40): string {
  return title.length > max ? title.slice(0, max - 1) + "…" : title;
}

// ─── Keyboards ────────────────────────────────────────────────────────────────

function getSearchKeyboard(results: SearchResult[]) {
  const nums = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"];
  return Markup.inlineKeyboard(
    results.map((r, i) => [
      Markup.button.callback(`${nums[i]} ${shortTitle(r.title)}`, `pick:${i}`),
    ])
  );
}

function getRemixKeyboard() {
  const rows: (keyof typeof EFFECTS)[][] = [
    ["slowed_reverb", "nightcore"],
    ["bass_boost",    "ultra_bass"],
    ["audio_8d",      "phonk"],
    ["hard_bass",     "reverb"],
    ["echo",          "lofi"],
    ["nightcore_bass","8d_reverb"],
    ["slowed_bass",   "phonk_reverb"],
  ];
  return Markup.inlineKeyboard(
    rows.map((row) =>
      row.map((k) => Markup.button.callback(EFFECTS[k]!.label, `remix:${k}`))
    )
  );
}

function getAdminKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback("✏️ Изменить /start",         "admin:set_start")],
    [Markup.button.callback("✏️ Изменить /help",          "admin:set_help")],
    [Markup.button.callback("✏️ Изменить /about",         "admin:set_about")],
    [Markup.button.callback("➕ Добавить администратора",  "admin:add_admin")],
    [Markup.button.callback("📋 Посмотреть текущие тексты","admin:show_texts")],
  ]);
}

// ─── Commands ─────────────────────────────────────────────────────────────────

bot.start((ctx) => {
  ctx.reply(config.start_message, { parse_mode: "Markdown" });
});

bot.help((ctx) => {
  ctx.reply(config.help_message, { parse_mode: "Markdown" });
});

bot.command("about", (ctx) => {
  ctx.reply(config.about_message, { parse_mode: "Markdown" });
});

bot.command("admin", async (ctx) => {
  if (!isAdmin(ctx.from.id)) {
    await ctx.reply("❌ У тебя нет прав администратора.");
    return;
  }
  await ctx.reply("👑 *Панель администратора*\n\nЧто хочешь изменить?", {
    parse_mode: "Markdown",
    ...getAdminKeyboard(),
  });
});

bot.command("myid", (ctx) => {
  ctx.reply(`🪪 Твой Telegram ID: \`${ctx.from.id}\``, { parse_mode: "Markdown" });
});

bot.command("cancel", (ctx) => {
  pendingAdminAction.delete(ctx.chat.id);
  ctx.reply("✅ Отменено.");
});

// ─── Admin callbacks ──────────────────────────────────────────────────────────

bot.action("admin:set_start", async (ctx) => {
  if (!isAdmin(ctx.from!.id)) { await ctx.answerCbQuery("❌ Нет прав"); return; }
  pendingAdminAction.set(ctx.chat!.id, "start");
  await ctx.answerCbQuery();
  await ctx.reply(
    "✏️ *Изменение /start*\n\nОтправь новый текст.\nПоддерживается Markdown: \\*жирный\\*, \\_курсив\\_\n\n/cancel — отмена",
    { parse_mode: "Markdown" }
  );
});

bot.action("admin:set_help", async (ctx) => {
  if (!isAdmin(ctx.from!.id)) { await ctx.answerCbQuery("❌ Нет прав"); return; }
  pendingAdminAction.set(ctx.chat!.id, "help");
  await ctx.answerCbQuery();
  await ctx.reply(
    "✏️ *Изменение /help*\n\nОтправь новый текст.\n\n/cancel — отмена",
    { parse_mode: "Markdown" }
  );
});

bot.action("admin:set_about", async (ctx) => {
  if (!isAdmin(ctx.from!.id)) { await ctx.answerCbQuery("❌ Нет прав"); return; }
  pendingAdminAction.set(ctx.chat!.id, "about");
  await ctx.answerCbQuery();
  await ctx.reply(
    "✏️ *Изменение /about*\n\nОтправь новый текст.\n\n/cancel — отмена",
    { parse_mode: "Markdown" }
  );
});

bot.action("admin:add_admin", async (ctx) => {
  if (!isAdmin(ctx.from!.id)) { await ctx.answerCbQuery("❌ Нет прав"); return; }
  pendingAdminAction.set(ctx.chat!.id, "add_admin");
  await ctx.answerCbQuery();
  await ctx.reply(
    "✏️ *Добавить администратора*\n\nОтправь числовой Telegram ID нового администратора.\n_(Узнать свой ID можно у @userinfobot)_\n\n/cancel — отмена",
    { parse_mode: "Markdown" }
  );
});

bot.action("admin:show_texts", async (ctx) => {
  if (!isAdmin(ctx.from!.id)) { await ctx.answerCbQuery("❌ Нет прав"); return; }
  await ctx.answerCbQuery();
  const admins = config.admin_ids.length ? config.admin_ids.join(", ") : "не заданы (только через ADMIN\\_IDS)";
  await ctx.reply(
    `📋 *Текущие настройки:*\n\n` +
    `*Администраторы:* ${admins}\n\n` +
    `*Текст /start:*\n${config.start_message}\n\n` +
    `*Текст /help:*\n${config.help_message}\n\n` +
    `*Текст /about:*\n${config.about_message}`,
    { parse_mode: "Markdown" }
  );
});

// ─── Text handler (search + admin input) ─────────────────────────────────────

bot.on("text", async (ctx) => {
  const query  = ctx.message.text.trim();
  if (query.startsWith("/")) return;

  const chatId = ctx.chat.id;
  const userId = ctx.from.id;

  // Handle pending admin input
  const action = pendingAdminAction.get(chatId);
  if (action && isAdmin(userId)) {
    pendingAdminAction.delete(chatId);

    if (action === "start") {
      config.start_message = query;
      saveConfig(config);
      await ctx.reply("✅ Текст /start обновлён! Вот как он выглядит:\n\n" + query, { parse_mode: "Markdown" });
      return;
    }
    if (action === "help") {
      config.help_message = query;
      saveConfig(config);
      await ctx.reply("✅ Текст /help обновлён!", { parse_mode: "Markdown" });
      return;
    }
    if (action === "about") {
      config.about_message = query;
      saveConfig(config);
      await ctx.reply("✅ Текст /about обновлён!", { parse_mode: "Markdown" });
      return;
    }
    if (action === "add_admin") {
      const newId = parseInt(query.trim());
      if (isNaN(newId)) {
        await ctx.reply("❌ Неверный ID — должно быть целое число.");
        return;
      }
      if (!config.admin_ids.includes(newId)) {
        config.admin_ids.push(newId);
        saveConfig(config);
      }
      await ctx.reply(`✅ Администратор с ID ${newId} добавлен.`);
      return;
    }
  }

  // Regular music search
  const msg = await ctx.reply(`🔍 Ищу: *${md(query)}*...`, { parse_mode: "Markdown" });

  try {
    const results = await searchYouTube(query);
    if (!results.length) {
      await ctx.telegram.editMessageText(chatId, msg.message_id, undefined, "❌ Ничего не нашёл. Попробуй другой запрос.");
      return;
    }

    searchResultsCache.set(chatId, results);

    const nums = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"];
    const list = results.map((r, i) => `${nums[i]} ${md(r.title)}`).join("\n");

    await ctx.telegram.editMessageText(
      chatId, msg.message_id, undefined,
      `🎵 *Нашёл ${results.length} вариантов:*\n\n${list}\n\nВыбери нужный 👇`,
      { parse_mode: "Markdown", ...getSearchKeyboard(results) }
    );
  } catch (err) {
    console.error("Search error:", err);
    await ctx.telegram
      .editMessageText(chatId, msg.message_id, undefined, "❌ Ошибка поиска. Попробуй ещё раз.")
      .catch(() => {});
  }
});

// ─── Pick a song ──────────────────────────────────────────────────────────────

bot.action(/^pick:(\d+)$/, async (ctx) => {
  const idx     = parseInt(ctx.match[1]!);
  const chatId  = ctx.chat!.id;
  const results = searchResultsCache.get(chatId);

  if (!results || !results[idx]) {
    await ctx.answerCbQuery("❌ Результаты устарели — ищи заново");
    return;
  }

  const chosen = results[idx]!;
  await ctx.answerCbQuery(`⬇️ Скачиваю: ${shortTitle(chosen.title, 30)}`);

  try {
    await ctx.editMessageText(
      `⬇️ Скачиваю: *${md(chosen.title)}*...`,
      { parse_mode: "Markdown" }
    );
  } catch {}

  const tmpDir       = os.tmpdir();
  const originalFile = path.join(tmpDir, `orig_${chatId}_${Date.now()}.mp3`);

  try {
    await downloadAudio(chosen.videoId, originalFile);

    if (!fs.existsSync(originalFile)) throw new Error("Downloaded file not found");

    // Clean up previous file
    const prev = pendingRemix.get(chatId);
    if (prev?.originalFile && fs.existsSync(prev.originalFile)) {
      try { fs.unlinkSync(prev.originalFile); } catch {}
    }

    pendingRemix.set(chatId, {
      title: chosen.title,
      videoId: chosen.videoId,
      uploader: chosen.uploader,
      originalFile,
    });
    searchResultsCache.delete(chatId);

    try { await ctx.deleteMessage(); } catch {}

    await ctx.replyWithAudio(
      { source: fs.createReadStream(originalFile) },
      {
        title: chosen.title,
        performer: "𝚋𝚢 𝚃𝚁𝙴",
        caption:
          `🎵 *${md(chosen.title)}*\n\n` +
          `Выбери ремикс — найду готовую версию на YouTube 👇`,
        parse_mode: "Markdown",
        ...getRemixKeyboard(),
      }
    );
  } catch (err) {
    console.error("Download error:", err);
    try {
      await ctx.editMessageText("❌ Ошибка при скачивании. Попробуй ещё раз или выбери другой вариант.");
    } catch {
      await ctx.reply("❌ Ошибка при скачивании. Попробуй ещё раз.");
    }
  }
});

// ─── Remix button ─────────────────────────────────────────────────────────────

bot.action(/^remix:(.+)$/, async (ctx) => {
  const effectKey = ctx.match[1]!;
  const effect    = EFFECTS[effectKey];
  if (!effect) { await ctx.answerCbQuery("❌ Неизвестный эффект"); return; }

  const chatId = ctx.chat!.id;
  const data   = pendingRemix.get(chatId);
  if (!data) {
    await ctx.answerCbQuery("❌ Сначала отправь название песни");
    return;
  }

  await ctx.answerCbQuery(`🔍 Ищу ${effect.label} на YouTube...`);
  const processingMsg = await ctx.reply(
    `🔍 Ищу *${effect.label}* версию на YouTube...\n🎵 ${md(data.title)}`,
    { parse_mode: "Markdown" }
  );

  const tmpDir  = os.tmpdir();
  const outFile = path.join(tmpDir, `remix_${chatId}_${effectKey}_${Date.now()}.mp3`);

  try {
    const { remixTitle, remixArtist } = await findAndDownloadRemix(
      data.title,
      effect.searchTerm,
      outFile
    );

    await ctx.telegram.deleteMessage(chatId, processingMsg.message_id).catch(() => {});

    await ctx.replyWithAudio(
      { source: fs.createReadStream(outFile) },
      {
        title: remixTitle,
        performer: "𝚋𝚢 𝚃𝚁𝙴",
        caption:
          `${effect.label}\n` +
          `🎵 *${md(remixTitle)}*`,
        parse_mode: "Markdown",
        ...getRemixKeyboard(),
      }
    );
  } catch (err) {
    console.error("Remix error:", err);
    await ctx.telegram.deleteMessage(chatId, processingMsg.message_id).catch(() => {});
    await ctx.reply(
      `❌ Не нашёл *${effect.label}* версию на YouTube. Попробуй другой эффект.`,
      { parse_mode: "Markdown" }
    );
  } finally {
    if (fs.existsSync(outFile)) try { fs.unlinkSync(outFile); } catch {}
  }
});

bot.action("noop", (ctx) => ctx.answerCbQuery());
